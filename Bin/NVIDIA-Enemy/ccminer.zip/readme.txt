If you find my miner useful, feel free to donte on my (RVN) or  run *.cmd for a while ;) 

My Raven (RVN): RM7EM5YWDkmEmNrTHFAGGLbeRiUmCHMnfG

Thanks.